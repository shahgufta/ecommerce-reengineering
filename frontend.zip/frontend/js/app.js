// ============================================================
// app.js — Core Functions (Cart, Auth, Alerts)
// Modern eCommerce System | Shahgufta | KIU
// ============================================================

// ── CART ────────────────────────────────────────────────────
function getCart()      { return JSON.parse(localStorage.getItem('cart') || '[]'); }
function saveCart(cart) { localStorage.setItem('cart', JSON.stringify(cart)); updateCartBadge(); }

function addToCart(item) {
  const cart = getCart();
  const existing = cart.find(i => i.id === item.id);
  if (existing) { existing.qty += 1; }
  else          { cart.push({...item, qty:1}); }
  saveCart(cart);
  showToast('Added to cart! 🛒', 'success');
}

function removeFromCart(id) { saveCart(getCart().filter(i => i.id !== id)); }

function updateQty(id, qty) {
  const cart = getCart();
  const item = cart.find(i => i.id === id);
  if (item) { item.qty = parseInt(qty); if (item.qty < 1) item.qty = 1; }
  saveCart(cart);
}

function clearCart()    { localStorage.removeItem('cart'); updateCartBadge(); }
function getCartTotal() { return getCart().reduce((s,i) => s + i.price * i.qty, 0); }
function getCartCount() { return getCart().reduce((s,i) => s + i.qty, 0); }

function updateCartBadge() {
  const count = getCartCount();
  document.querySelectorAll('.cart-badge').forEach(el => el.textContent = count);
}

// ── AUTH ─────────────────────────────────────────────────────
function getUser()  { return JSON.parse(localStorage.getItem('user') || 'null'); }
function isLoggedIn(){ return !!getUser(); }

function logout() {
  localStorage.removeItem('user');
  showToast('Logged out!', 'info');
  setTimeout(() => location.href = getRootPath() + 'index.html', 800);
}

function getRootPath() {
  return window.location.pathname.includes('/pages/') ? '../' : '';
}

function updateNavAuth() {
  const user = getUser();
  const loginLink  = document.getElementById('navLogin');
  const logoutLink = document.getElementById('navLogout');
  const userName   = document.getElementById('navUserName');
  if (user) {
    if (loginLink)  loginLink.style.display  = 'none';
    if (logoutLink) logoutLink.style.display = 'inline';
    if (userName)   userName.textContent     = user.name.split(' ')[0];
  }
}

// ── TOAST ────────────────────────────────────────────────────
function showToast(msg, type='success') {
  document.querySelectorAll('.toast').forEach(t => t.remove());
  const t = document.createElement('div');
  t.className = `alert alert-${type} toast`;
  t.style.cssText = 'position:fixed;top:72px;right:16px;z-index:9999;min-width:240px;animation:slideIn 0.3s ease;max-width:320px;';
  t.innerHTML = msg;
  document.body.appendChild(t);
  setTimeout(() => t.style.opacity='0', 2500);
  setTimeout(() => t.remove(), 3000);
}

// ── SEARCH ───────────────────────────────────────────────────
function doSearch() {
  const q = document.getElementById('navSearchInput')?.value?.trim();
  if (q) {
    const root = getRootPath();
    location.href = root + 'pages/products.html?search=' + encodeURIComponent(q);
  }
}

// ── INIT ─────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  updateCartBadge();
  updateNavAuth();

  // Enter key search
  document.getElementById('navSearchInput')?.addEventListener('keypress', e => {
    if (e.key === 'Enter') doSearch();
  });
});
