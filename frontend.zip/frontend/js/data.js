// ============================================================
// data.js — Products & Categories Data
// Modern eCommerce System | Shahgufta | KIU
// ============================================================

const CATEGORIES = [
  { id:'cat1', name:'Electronics',  emoji:'💻', count:4 },
  { id:'cat2', name:'Clothing',     emoji:'👕', count:4 },
  { id:'cat3', name:'Books',        emoji:'📚', count:3 },
  { id:'cat4', name:'Sports',       emoji:'⚽', count:3 },
  { id:'cat5', name:'Home & Garden',emoji:'🏠', count:3 },
  { id:'cat6', name:'Beauty',       emoji:'💄', count:3 },
];

const PRODUCTS = [
  { id:'p001', name:'Laptop Pro 15"',       price:85000, oldPrice:95000, category:'Electronics', emoji:'💻', stock:10, rating:4.5, reviews:128, badge:'sale', desc:'Intel Core i7, 16GB RAM, 512GB SSD — perfect for work and study.' },
  { id:'p002', name:'Samsung Galaxy S24',   price:45000, oldPrice:null,  category:'Electronics', emoji:'📱', stock:25, rating:4.7, reviews:89,  badge:'new',  desc:'Latest Android flagship with 6.2" display and 50MP camera.' },
  { id:'p003', name:'Wireless Earbuds Pro', price:8500,  oldPrice:12000, category:'Electronics', emoji:'🎧', stock:40, rating:4.3, reviews:56,  badge:'sale', desc:'Active noise cancellation, 30hr battery life.' },
  { id:'p004', name:'Smart Watch Series 9', price:15000, oldPrice:null,  category:'Electronics', emoji:'⌚', stock:15, rating:4.6, reviews:34,  badge:'new',  desc:'Health tracking, GPS, AMOLED display.' },
  { id:'p005', name:'Premium Cotton T-Shirt',price:1800, oldPrice:null,  category:'Clothing',    emoji:'👕', stock:100,rating:4.2, reviews:45,  badge:null,   desc:'100% organic cotton, available in 8 colors.' },
  { id:'p006', name:'Slim Fit Jeans',        price:4500, oldPrice:6000,  category:'Clothing',    emoji:'👖', stock:60, rating:4.4, reviews:67,  badge:'sale', desc:'Stretch denim, modern slim fit design.' },
  { id:'p007', name:'Running Sneakers',      price:7500, oldPrice:null,  category:'Clothing',    emoji:'👟', stock:30, rating:4.5, reviews:89,  badge:'new',  desc:'Lightweight foam sole, breathable mesh upper.' },
  { id:'p008', name:'Winter Jacket',         price:12000,oldPrice:15000, category:'Clothing',    emoji:'🧥', stock:20, rating:4.3, reviews:23,  badge:'sale', desc:'Water-resistant, down-filled, extra warm.' },
  { id:'p009', name:'Python Programming',    price:2500, oldPrice:null,  category:'Books',       emoji:'📗', stock:50, rating:4.8, reviews:234, badge:null,   desc:'Complete Python guide from beginner to advanced.' },
  { id:'p010', name:'Web Development Guide', price:2200, oldPrice:null,  category:'Books',       emoji:'📘', stock:45, rating:4.6, reviews:178, badge:'new',  desc:'HTML, CSS, JavaScript, React — all in one book.' },
  { id:'p011', name:'Data Structures Book',  price:1800, oldPrice:null,  category:'Books',       emoji:'📙', stock:30, rating:4.7, reviews:145, badge:null,   desc:'Algorithms and data structures for interviews.' },
  { id:'p012', name:'Football (FIFA)',        price:3500, oldPrice:null,  category:'Sports',      emoji:'⚽', stock:20, rating:4.4, reviews:56,  badge:null,   desc:'FIFA approved match ball, size 5.' },
  { id:'p013', name:'Cricket Bat (English)',  price:6500, oldPrice:8000,  category:'Sports',      emoji:'🏏', stock:12, rating:4.6, reviews:34,  badge:'sale', desc:'English willow, Grade 1, 2.8lbs weight.' },
  { id:'p014', name:'Yoga Mat Premium',       price:2500, oldPrice:null,  category:'Sports',      emoji:'🧘', stock:35, rating:4.5, reviews:89,  badge:'new',  desc:'Non-slip, 6mm thick, eco-friendly material.' },
  { id:'p015', name:'Coffee Maker',           price:8500, oldPrice:null,  category:'Home & Garden',emoji:'☕',stock:18, rating:4.3, reviews:45,  badge:'new',  desc:'12-cup capacity, programmable, auto shut-off.' },
  { id:'p016', name:'Air Purifier',           price:18000,oldPrice:22000, category:'Home & Garden',emoji:'💨',stock:8,  rating:4.7, reviews:67,  badge:'sale', desc:'HEPA filter, 400 sq ft coverage, ultra quiet.' },
  { id:'p017', name:'Plant Pot Set',          price:1500, oldPrice:null,  category:'Home & Garden',emoji:'🌱',stock:50, rating:4.2, reviews:23,  badge:null,   desc:'Set of 3 ceramic pots with drainage holes.' },
  { id:'p018', name:'Face Serum Vitamin C',   price:3500, oldPrice:null,  category:'Beauty',      emoji:'✨', stock:40, rating:4.6, reviews:112, badge:'new',  desc:'Brightening serum, dermatologist tested.' },
  { id:'p019', name:'Hair Care Set',          price:2800, oldPrice:4000,  category:'Beauty',      emoji:'💆', stock:25, rating:4.4, reviews:78,  badge:'sale', desc:'Shampoo + conditioner + hair mask bundle.' },
  { id:'p020', name:'Perfume Collection',     price:6500, oldPrice:null,  category:'Beauty',      emoji:'🌸', stock:15, rating:4.8, reviews:56,  badge:null,   desc:'3 premium fragrances in elegant bottles.' },
];

function getProducts(category=null, search=null) {
  let list = [...PRODUCTS];
  if (category) list = list.filter(p => p.category === category);
  if (search)   list = list.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
  return list;
}

function getProduct(id) {
  return PRODUCTS.find(p => p.id === id);
}

function getCategories() { return CATEGORIES; }

function formatPrice(p) { return 'Rs. ' + Number(p).toLocaleString(); }

function starsHTML(rating) {
  const full  = Math.floor(rating);
  const half  = rating % 1 >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  return '★'.repeat(full) + (half?'½':'') + '☆'.repeat(empty);
}

function productCard(p, subPage=true) {
  const prefix = subPage ? '../' : '';
  return `
  <div class="product-card">
    <div class="product-thumb">
      ${p.badge ? `<span class="badge-${p.badge}">${p.badge.toUpperCase()}</span>` : ''}
      ${p.emoji}
    </div>
    <div class="product-body">
      <div class="product-category">${p.category}</div>
      <div class="product-name">${p.name}</div>
      <div class="product-rating">
        <span class="stars">${starsHTML(p.rating)}</span>
        <span class="rating-count">(${p.reviews})</span>
      </div>
      <div class="product-price-row">
        <span class="product-price">${formatPrice(p.price)}</span>
        ${p.oldPrice ? `<span class="product-old-price">${formatPrice(p.oldPrice)}</span>` : ''}
      </div>
      <div class="product-stock">✓ In Stock (${p.stock} left)</div>
      <div class="product-actions">
        <button class="btn btn-accent btn-sm" style="flex:1" onclick='addToCart(${JSON.stringify({id:p.id,name:p.name,price:p.price,emoji:p.emoji})})'>🛒 Add to Cart</button>
        <a href="${prefix}pages/product-detail.html?id=${p.id}" class="btn btn-outline btn-sm">View</a>
      </div>
    </div>
  </div>`;
}
