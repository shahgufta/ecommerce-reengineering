// ============================================================
// products.js — Product Data & Card Component
// SE-601 Software Re-Engineering | Shahgufta | KIU
// ============================================================

// Sample product data (connects to backend API in production)
function getProducts(category = null) {
  const all = [
    { product_id:'p001', name:'Laptop',             price:75000, category:'Electronics', stock:10, icon:'💻' },
    { product_id:'p002', name:'Mobile Phone',        price:35000, category:'Electronics', stock:25, icon:'📱' },
    { product_id:'p003', name:'Wireless Earbuds',    price:8500,  category:'Electronics', stock:40, icon:'🎧' },
    { product_id:'p004', name:'Smart Watch',         price:12000, category:'Electronics', stock:15, icon:'⌚' },
    { product_id:'p005', name:'T-Shirt',             price:1500,  category:'Clothing',    stock:100, icon:'👕' },
    { product_id:'p006', name:'Jeans',               price:3500,  category:'Clothing',    stock:60, icon:'👖' },
    { product_id:'p007', name:'Sneakers',            price:6500,  category:'Clothing',    stock:30, icon:'👟' },
    { product_id:'p008', name:'Python Programming',  price:2000,  category:'Books',       stock:50, icon:'📗' },
    { product_id:'p009', name:'Web Development',     price:1800,  category:'Books',       stock:45, icon:'📘' },
    { product_id:'p010', name:'Football',            price:2500,  category:'Sports',      stock:20, icon:'⚽' },
    { product_id:'p011', name:'Cricket Bat',         price:4500,  category:'Sports',      stock:12, icon:'🏏' },
    { product_id:'p012', name:'Yoga Mat',            price:1200,  category:'Sports',      stock:35, icon:'🧘' },
  ];
  if (category) return all.filter(p => p.category === category);
  return all;
}

// Product card HTML
function productCard(p) {
  // Detect if we're in pages/ subfolder
  const isSubPage = window.location.pathname.includes('/pages/');
  const jsPath = isSubPage ? '../js/app.js' : 'js/app.js';

  return `
    <div class="product-card">
      <div class="product-img">${p.icon}</div>
      <div class="product-info">
        <div class="product-category">${p.category}</div>
        <div class="product-name">${p.name}</div>
        <div class="product-price">${formatPrice(p.price)}</div>
        <div class="product-stock">✓ In Stock (${p.stock})</div>
        <button class="btn-secondary" style="width:100%"
          onclick='addToCart(${JSON.stringify(p)})'>
          Add to Cart 🛒
        </button>
      </div>
    </div>
  `;
}
