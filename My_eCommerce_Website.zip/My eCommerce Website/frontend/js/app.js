// ============================================================
// app.js — Global JavaScript Functions
// SE-601 Software Re-Engineering | Shahgufta | KIU
// ============================================================

// ── CART FUNCTIONS ──────────────────────────────────────────

function getCart() {
  return JSON.parse(localStorage.getItem('cart') || '[]');
}

function saveCart(cart) {
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
}

function addToCart(product) {
  const cart = getCart();
  const existing = cart.find(i => i.product_id === product.product_id);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ ...product, quantity: 1 });
  }
  saveCart(cart);
  showAlert('Item added to cart! 🛒', 'success');
}

function removeFromCart(product_id) {
  const cart = getCart().filter(i => i.product_id !== product_id);
  saveCart(cart);
}

function clearCart() {
  localStorage.removeItem('cart');
  updateCartCount();
}

function getCartTotal() {
  return getCart().reduce((sum, i) => sum + i.price * i.quantity, 0);
}

function updateCartCount() {
  const count = getCart().reduce((sum, i) => sum + i.quantity, 0);
  const el = document.getElementById('cartCount');
  if (el) el.textContent = count;
}

// ── AUTH FUNCTIONS ──────────────────────────────────────────

function getUser() {
  return JSON.parse(localStorage.getItem('user') || 'null');
}

function checkLogin() {
  const user = getUser();
  const loginBtn  = document.getElementById('loginBtn');
  const logoutBtn = document.getElementById('logoutBtn');
  if (user) {
    if (loginBtn)  loginBtn.textContent = user.name;
    if (logoutBtn) logoutBtn.style.display = 'inline';
    if (loginBtn)  loginBtn.style.display = 'none';
  }
}

function logout() {
  localStorage.removeItem('user');
  location.href = '../index.html';
}

// ── ALERT FUNCTION ──────────────────────────────────────────

function showAlert(message, type = 'success') {
  const existing = document.querySelector('.alert-toast');
  if (existing) existing.remove();

  const div = document.createElement('div');
  div.className = `alert alert-${type} alert-toast`;
  div.style.cssText = `
    position:fixed; top:70px; right:20px; z-index:999;
    min-width:250px; animation: fadeIn 0.3s ease;
  `;
  div.textContent = message;
  document.body.appendChild(div);
  setTimeout(() => div.remove(), 3000);
}

// ── CURRENCY FORMAT ─────────────────────────────────────────
function formatPrice(price) {
  return 'Rs. ' + Number(price).toLocaleString();
}

// On every page load
document.addEventListener('DOMContentLoaded', () => {
  updateCartCount();
  checkLogin();
});
