# 🛒 My eCommerce Website
## SE-601 Software Re-Engineering | Shahgufta | KIU | June 2026
**Instructor:** Asif Hussain
**GitHub:** https://github.com/Shahgufta/ecommerce-reengineering

---

## 📁 Complete Folder Structure

```
My eCommerce Website/
│
├── frontend/                    ← Website (HTML + CSS + JS)
│   ├── index.html               ← Home page
│   ├── css/
│   │   └── style.css            ← All styles
│   ├── js/
│   │   ├── app.js               ← Cart, Login, Alert functions
│   │   └── products.js          ← Product data & card component
│   └── pages/
│       ├── products.html        ← Products listing + search + filter
│       ├── cart.html            ← Shopping cart
│       ├── checkout.html        ← Order form + payment method
│       ├── order-success.html   ← Order confirmation
│       ├── orders.html          ← My orders history
│       └── login.html           ← Login + Register
│
├── backend/                     ← Modernized microservices (Python)
│   ├── user-service/
│   │   ├── main.py              ← Login/Register API
│   │   └── database.py          ← Users database (SQLite)
│   ├── product-service/
│   │   ├── main.py              ← Products API
│   │   └── database.py          ← Products + Categories database
│   ├── cart-service/
│   │   ├── main.py              ← Cart API
│   │   └── database.py          ← Cart database
│   ├── order-service/
│   │   ├── main.py              ← Orders API
│   │   └── database.py          ← Orders + OrderItems database
│   └── payment-service/
│       ├── main.py              ← Payments API
│       └── database.py          ← Payments database
│
├── legacy-system/               ← Old PHP system (for comparison)
│   ├── src/
│   │   ├── index.php            ← Old entry point (problems shown)
│   │   ├── products.php         ← SQL Injection example
│   │   ├── checkout.php         ← God File (1200 lines)
│   │   ├── user.php             ← MD5 passwords
│   │   └── db_connect.php       ← Hardcoded credentials
│   └── db/
│       ├── legacy_schema.sql    ← Old broken database
│       └── modernized_schema.sql ← New 3NF database
│
├── diagrams/                    ← Architecture diagrams (PNG)
│   ├── 01_ER_Diagram.png        ← Database structure
│   ├── 02_System_Architecture.png ← Full system
│   ├── 03_Use_Case_Diagram.png  ← Use cases
│   ├── 04_Sequence_Diagram.png  ← Order flow
│   └── 05_Class_Diagram.png     ← Classes
│
└── docs/                        ← Documents
    ├── SE601_Assignment_ECommerce.pdf
    └── SE601_Presentation.pptx
```

---

## 🚀 How to Run Frontend

1. Open `frontend/index.html` in any browser
2. No installation needed!

## 🚀 How to Run Backend

```bash
pip install fastapi uvicorn
cd backend/user-service
uvicorn main:app --reload --port 3001
```

---

## Legacy vs Modernized

| Issue | Legacy (PHP) | Modernized |
|-------|-------------|------------|
| Architecture | Monolithic | Microservices |
| Frontend | PHP + HTML mixed | Clean HTML/CSS/JS |
| Database | 1NF violations | 3NF normalized |
| Security | SQL Injection | Prepared statements |
| Passwords | MD5 | bcrypt hash |
