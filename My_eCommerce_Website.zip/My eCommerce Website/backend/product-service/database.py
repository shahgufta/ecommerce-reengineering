# ============================================================
# PRODUCT SERVICE — database.py
# Database models and operations for Product Service
# SE-601 | Shahgufta | KIU
# ============================================================

import sqlite3
import uuid

DB_PATH = "products.db"

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def create_tables():
    """Create products and categories tables"""
    conn = get_connection()

    # Categories table (was just text in legacy!)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS categories (
            category_id TEXT PRIMARY KEY,
            name        TEXT NOT NULL,
            description TEXT
        )
    """)

    # Products table with FK to categories
    conn.execute("""
        CREATE TABLE IF NOT EXISTS products (
            product_id  TEXT PRIMARY KEY,
            category_id TEXT REFERENCES categories(category_id),
            name        TEXT NOT NULL,
            price       REAL NOT NULL,
            stock       INTEGER DEFAULT 0,
            description TEXT,
            is_active   INTEGER DEFAULT 1,
            created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Insert sample data
    conn.execute("""
        INSERT OR IGNORE INTO categories VALUES
        ('cat1', 'Electronics', 'Electronic items'),
        ('cat2', 'Clothing',    'Clothes and fashion'),
        ('cat3', 'Books',       'Books and education')
    """)
    conn.execute("""
        INSERT OR IGNORE INTO products VALUES
        ('p001', 'cat1', 'Laptop',              75000, 10, '15 inch laptop', 1, CURRENT_TIMESTAMP),
        ('p002', 'cat1', 'Mobile Phone',        35000, 25, 'Android phone',  1, CURRENT_TIMESTAMP),
        ('p003', 'cat2', 'T-Shirt',              1500,100, 'Cotton t-shirt', 1, CURRENT_TIMESTAMP),
        ('p004', 'cat3', 'Python Programming',   2000, 50, 'Learn Python',   1, CURRENT_TIMESTAMP)
    """)
    conn.commit()
    conn.close()
    print("Products & Categories tables ready!")

def get_all_products(category: str = None) -> list:
    """Get all products, optionally filter by category name"""
    conn = get_connection()
    if category:
        rows = conn.execute("""
            SELECT p.*, c.name as category_name
            FROM products p
            JOIN categories c ON p.category_id = c.category_id
            WHERE c.name = ? AND p.is_active = 1
        """, (category,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT p.*, c.name as category_name
            FROM products p
            JOIN categories c ON p.category_id = c.category_id
            WHERE p.is_active = 1
        """).fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_product_by_id(product_id: str) -> dict:
    """Get single product"""
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM products WHERE product_id = ?", (product_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None

def insert_product(name, price, stock, category_id, description="") -> dict:
    """Add new product"""
    conn = get_connection()
    product_id = str(uuid.uuid4())[:8]
    conn.execute("""
        INSERT INTO products (product_id, category_id, name, price, stock, description)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (product_id, category_id, name, price, stock, description))
    conn.commit()
    conn.close()
    return get_product_by_id(product_id)

def update_stock(product_id: str, new_stock: int):
    """Update product stock"""
    conn = get_connection()
    conn.execute(
        "UPDATE products SET stock = ? WHERE product_id = ?",
        (new_stock, product_id)
    )
    conn.commit()
    conn.close()

def search_products(keyword: str) -> list:
    """Search products by name"""
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM products WHERE name LIKE ? AND is_active = 1",
        (f"%{keyword}%",)  # Safe — using prepared statement
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]

create_tables()
