# =============================================
# PRODUCT SERVICE — Modernized E-Commerce System
# SE-601 Software Re-Engineering
# Student: Shahgufta | KIU
# =============================================

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import uuid

app = FastAPI(title="Product Service", version="1.0.0")

# In-memory database (for demonstration)
products_db = {
    "p001": {"id": "p001", "name": "Laptop", "price": 75000, "stock": 10, "category": "Electronics"},
    "p002": {"id": "p002", "name": "Mobile Phone", "price": 35000, "stock": 25, "category": "Electronics"},
    "p003": {"id": "p003", "name": "T-Shirt", "price": 1500, "stock": 100, "category": "Clothing"},
    "p004": {"id": "p004", "name": "Book - Python Programming", "price": 2000, "stock": 50, "category": "Books"},
}

# ---- Models ----
class ProductCreate(BaseModel):
    name: str
    price: float
    stock: int
    category: str

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    stock: Optional[int] = None

# ---- Routes ----

@app.get("/")
def home():
    return {"service": "Product Service", "status": "running"}

@app.get("/products")
def get_all_products(category: Optional[str] = None):
    """Get all products, optionally filter by category"""
    products = list(products_db.values())
    if category:
        products = [p for p in products if p["category"].lower() == category.lower()]
    return {"products": products, "total": len(products)}

@app.get("/products/{product_id}")
def get_product(product_id: str):
    """Get single product by ID"""
    if product_id not in products_db:
        raise HTTPException(status_code=404, detail="Product not found")
    return products_db[product_id]

@app.post("/products")
def create_product(data: ProductCreate):
    """Add new product"""
    product_id = "p" + str(uuid.uuid4())[:4]
    products_db[product_id] = {
        "id": product_id,
        "name": data.name,
        "price": data.price,
        "stock": data.stock,
        "category": data.category
    }
    return {"message": "Product created", "product": products_db[product_id]}

@app.put("/products/{product_id}")
def update_product(product_id: str, data: ProductUpdate):
    """Update product details"""
    if product_id not in products_db:
        raise HTTPException(status_code=404, detail="Product not found")
    if data.name: products_db[product_id]["name"] = data.name
    if data.price: products_db[product_id]["price"] = data.price
    if data.stock is not None: products_db[product_id]["stock"] = data.stock
    return {"message": "Product updated", "product": products_db[product_id]}

@app.delete("/products/{product_id}")
def delete_product(product_id: str):
    """Delete a product"""
    if product_id not in products_db:
        raise HTTPException(status_code=404, detail="Product not found")
    del products_db[product_id]
    return {"message": "Product deleted successfully"}

@app.get("/products/search/{keyword}")
def search_products(keyword: str):
    """Search products by name"""
    results = [p for p in products_db.values() if keyword.lower() in p["name"].lower()]
    return {"results": results, "count": len(results)}
