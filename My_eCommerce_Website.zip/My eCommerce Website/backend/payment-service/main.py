# =============================================
# PAYMENT SERVICE — Modernized E-Commerce System
# SE-601 Software Re-Engineering
# Student: Shahgufta | KIU
# =============================================

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from datetime import datetime
import uuid

app = FastAPI(title="Payment Service", version="1.0.0")

# In-memory payments database
payments_db = {}

# ---- Models ----
class PaymentRequest(BaseModel):
    order_id: str
    amount: float
    method: str  # "cash", "card", "easypaisa", "jazzcash"
    user_id: str

# ---- Routes ----

@app.get("/")
def home():
    return {"service": "Payment Service", "status": "running"}

@app.post("/payments/process")
def process_payment(data: PaymentRequest):
    """Process a payment"""
    valid_methods = ["cash", "card", "easypaisa", "jazzcash"]
    if data.method not in valid_methods:
        raise HTTPException(status_code=400, detail=f"Invalid method. Use: {valid_methods}")
    if data.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be greater than 0")

    payment_id = "PAY-" + str(uuid.uuid4())[:8].upper()
    transaction_id = "TXN-" + str(uuid.uuid4())[:12].upper()

    payments_db[payment_id] = {
        "payment_id": payment_id,
        "transaction_id": transaction_id,
        "order_id": data.order_id,
        "user_id": data.user_id,
        "amount": data.amount,
        "method": data.method,
        "status": "success",
        "paid_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    return {
        "message": "Payment successful!",
        "payment": payments_db[payment_id]
    }

@app.get("/payments/{payment_id}")
def get_payment(payment_id: str):
    """Get payment details"""
    if payment_id not in payments_db:
        raise HTTPException(status_code=404, detail="Payment not found")
    return payments_db[payment_id]

@app.post("/payments/{payment_id}/refund")
def refund_payment(payment_id: str):
    """Refund a payment"""
    if payment_id not in payments_db:
        raise HTTPException(status_code=404, detail="Payment not found")
    if payments_db[payment_id]["status"] == "refunded":
        raise HTTPException(status_code=400, detail="Payment already refunded")

    payments_db[payment_id]["status"] = "refunded"
    return {"message": "Payment refunded successfully", "payment_id": payment_id}
