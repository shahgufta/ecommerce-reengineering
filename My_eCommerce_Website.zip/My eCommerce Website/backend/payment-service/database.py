# ============================================================
# PAYMENT SERVICE — database.py
# Database models and operations for Payment Service
# SE-601 | Shahgufta | KIU
# ============================================================

import sqlite3
import uuid
from datetime import datetime

DB_PATH = "payments.db"

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def create_tables():
    """Create payments table"""
    conn = get_connection()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            payment_id     TEXT PRIMARY KEY,
            order_id       TEXT NOT NULL,
            user_id        TEXT NOT NULL,
            amount         REAL NOT NULL,
            method         TEXT NOT NULL,
            status         TEXT DEFAULT 'success',
            transaction_id TEXT UNIQUE,  -- No duplicate payments!
            paid_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()
    print("Payments table ready!")

def create_payment(order_id: str, user_id: str,
                   amount: float, method: str) -> dict:
    """Record a new payment"""
    conn = get_connection()
    payment_id     = "PAY-" + str(uuid.uuid4())[:8].upper()
    transaction_id = "TXN-" + str(uuid.uuid4())[:12].upper()

    conn.execute("""
        INSERT INTO payments
        (payment_id, order_id, user_id, amount, method, transaction_id)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (payment_id, order_id, user_id, amount, method, transaction_id))

    conn.commit()
    conn.close()
    return get_payment(payment_id)

def get_payment(payment_id: str) -> dict:
    """Get payment by ID"""
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM payments WHERE payment_id = ?", (payment_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None

def get_payment_by_order(order_id: str) -> dict:
    """Get payment for an order"""
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM payments WHERE order_id = ?", (order_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None

def refund_payment(payment_id: str):
    """Mark payment as refunded"""
    conn = get_connection()
    conn.execute(
        "UPDATE payments SET status = 'refunded' WHERE payment_id = ?",
        (payment_id,)
    )
    conn.commit()
    conn.close()

create_tables()
