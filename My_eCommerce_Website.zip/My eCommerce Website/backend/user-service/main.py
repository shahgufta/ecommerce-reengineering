# =============================================
# USER SERVICE — Modernized E-Commerce System
# SE-601 Software Re-Engineering
# Student: Shahgufta | KIU
# =============================================

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import hashlib
import uuid

app = FastAPI(title="User Service", version="1.0.0")

# In-memory database (for demonstration)
users_db = {}

# ---- Models ----
class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str

class LoginRequest(BaseModel):
    email: str
    password: str

# ---- Helper ----
def hash_password(password: str) -> str:
    # bcrypt in production — SHA256 for demo
    return hashlib.sha256(password.encode()).hexdigest()

# ---- Routes ----

@app.get("/")
def home():
    return {"service": "User Service", "status": "running"}

@app.post("/auth/register")
def register(data: RegisterRequest):
    """Register a new user"""
    # Check if email already exists
    for user in users_db.values():
        if user["email"] == data.email:
            raise HTTPException(status_code=400, detail="Email already registered")

    user_id = str(uuid.uuid4())
    users_db[user_id] = {
        "id": user_id,
        "name": data.name,
        "email": data.email,
        "password_hash": hash_password(data.password)  # Never store plaintext!
    }
    return {"message": "User registered successfully", "user_id": user_id}

@app.post("/auth/login")
def login(data: LoginRequest):
    """Login and return token"""
    for user in users_db.values():
        if user["email"] == data.email:
            if user["password_hash"] == hash_password(data.password):
                token = str(uuid.uuid4())  # JWT in production
                return {"message": "Login successful", "token": token}
    raise HTTPException(status_code=401, detail="Invalid email or password")

@app.get("/users/{user_id}")
def get_user(user_id: str):
    """Get user profile"""
    if user_id not in users_db:
        raise HTTPException(status_code=404, detail="User not found")
    user = users_db[user_id].copy()
    del user["password_hash"]  # Never return password
    return user

@app.get("/users")
def get_all_users():
    """Get all users (admin only)"""
    return [
        {"id": u["id"], "name": u["name"], "email": u["email"]}
        for u in users_db.values()
    ]
