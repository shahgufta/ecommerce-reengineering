# ============================================================
# USER SERVICE — database.py
# Database models and operations for User Service
# SE-601 | Shahgufta | KIU
# ============================================================

import sqlite3
import uuid
import hashlib
import os

DB_PATH = "users.db"

def get_connection():
    """Get database connection"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Return dict-like rows
    return conn

def create_tables():
    """Create users table if not exists"""
    conn = get_connection()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id       TEXT PRIMARY KEY,
            name          TEXT NOT NULL,
            email         TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role          TEXT DEFAULT 'customer',
            is_active     INTEGER DEFAULT 1,
            created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()
    print("Users table ready!")

def hash_password(password: str) -> str:
    """Hash password using SHA256 (bcrypt in production)"""
    return hashlib.sha256(password.encode()).hexdigest()

def insert_user(name: str, email: str, password: str) -> dict:
    """Insert new user into database"""
    conn = get_connection()
    user_id = str(uuid.uuid4())
    password_hash = hash_password(password)

    conn.execute("""
        INSERT INTO users (user_id, name, email, password_hash)
        VALUES (?, ?, ?, ?)
    """, (user_id, name, email, password_hash))
    # ↑ Using ? placeholders — NO SQL INJECTION!

    conn.commit()
    conn.close()
    return {"user_id": user_id, "name": name, "email": email}

def find_user_by_email(email: str) -> dict:
    """Find user by email"""
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM users WHERE email = ?", (email,)
        # ↑ Prepared statement — secure!
    ).fetchone()
    conn.close()
    return dict(row) if row else None

def find_user_by_id(user_id: str) -> dict:
    """Find user by ID"""
    conn = get_connection()
    row = conn.execute(
        "SELECT user_id, name, email, role FROM users WHERE user_id = ?",
        (user_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None

def get_all_users() -> list:
    """Get all users (admin only)"""
    conn = get_connection()
    rows = conn.execute(
        "SELECT user_id, name, email, role, created_at FROM users"
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]

# Initialize database on import
create_tables()
