# =============================================
# ORDER SERVICE — Modernized E-Commerce System
# SE-601 Software Re-Engineering
# Student: Shahgufta | KIU
# =============================================

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
from datetime import datetime
import uuid

app = FastAPI(title="Order Service", version="1.0.0")

# In-memory orders database
orders_db = {}

# ---- Models ----
class OrderItem(BaseModel):
    product_id: str
    product_name: str
    price: float
    quantity: int

class OrderCreate(BaseModel):
    user_id: str
    items: List[OrderItem]
    address: str
    payment_method: str

# ---- Routes ----

@app.get("/")
def home():
    return {"service": "Order Service", "status": "running"}

@app.post("/orders")
def place_order(data: OrderCreate):
    """Place a new order"""
    if not data.items:
        raise HTTPException(status_code=400, detail="Order must have at least one item")

    order_id = "ORD-" + str(uuid.uuid4())[:8].upper()
    total = sum(item.price * item.quantity for item in data.items)

    orders_db[order_id] = {
        "order_id": order_id,
        "user_id": data.user_id,
        "items": [item.dict() for item in data.items],
        "total": round(total, 2),
        "address": data.address,
        "payment_method": data.payment_method,
        "status": "confirmed",
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    return {"message": "Order placed successfully!", "order": orders_db[order_id]}

@app.get("/orders/{order_id}")
def get_order(order_id: str):
    """Get order by ID"""
    if order_id not in orders_db:
        raise HTTPException(status_code=404, detail="Order not found")
    return orders_db[order_id]

@app.get("/orders/user/{user_id}")
def get_user_orders(user_id: str):
    """Get all orders for a user"""
    user_orders = [o for o in orders_db.values() if o["user_id"] == user_id]
    return {"orders": user_orders, "total_orders": len(user_orders)}

@app.put("/orders/{order_id}/status")
def update_order_status(order_id: str, status: str):
    """Update order status"""
    valid_statuses = ["confirmed", "processing", "shipped", "delivered", "cancelled"]
    if status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Invalid status. Use: {valid_statuses}")
    if order_id not in orders_db:
        raise HTTPException(status_code=404, detail="Order not found")
    
    orders_db[order_id]["status"] = status
    return {"message": f"Order status updated to '{status}'", "order_id": order_id}

@app.delete("/orders/{order_id}/cancel")
def cancel_order(order_id: str):
    """Cancel an order"""
    if order_id not in orders_db:
        raise HTTPException(status_code=404, detail="Order not found")
    if orders_db[order_id]["status"] == "delivered":
        raise HTTPException(status_code=400, detail="Cannot cancel delivered order")
    
    orders_db[order_id]["status"] = "cancelled"
    return {"message": "Order cancelled successfully", "order_id": order_id}
