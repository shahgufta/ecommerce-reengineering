# ============================================================
# ORDER SERVICE — database.py
# Database models and operations for Order Service
# SE-601 | Shahgufta | KIU
# ============================================================

import sqlite3
import uuid
from datetime import datetime

DB_PATH = "orders.db"

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def create_tables():
    """Create orders and order_items tables"""
    conn = get_connection()

    # Orders table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            order_id   TEXT PRIMARY KEY,
            user_id    TEXT NOT NULL,
            status     TEXT DEFAULT 'confirmed',
            total      REAL NOT NULL,
            address    TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Order items table — SEPARATE TABLE (fixes 1NF violation from legacy!)
    # Legacy had: items = "1:2,3:1" — wrong!
    # Modern has: separate row per item — correct!
    conn.execute("""
        CREATE TABLE IF NOT EXISTS order_items (
            item_id      TEXT PRIMARY KEY,
            order_id     TEXT REFERENCES orders(order_id),
            product_id   TEXT NOT NULL,
            product_name TEXT NOT NULL,
            quantity     INTEGER NOT NULL,
            unit_price   REAL NOT NULL
        )
    """)

    conn.commit()
    conn.close()
    print("Orders & OrderItems tables ready!")

def create_order(user_id: str, items: list, total: float, address: str) -> dict:
    """Create new order with items"""
    conn = get_connection()
    order_id = "ORD-" + str(uuid.uuid4())[:8].upper()

    # Insert order
    conn.execute("""
        INSERT INTO orders (order_id, user_id, total, address)
        VALUES (?, ?, ?, ?)
    """, (order_id, user_id, total, address))

    # Insert each item separately (NOT as CSV string like legacy!)
    for item in items:
        item_id = str(uuid.uuid4())
        conn.execute("""
            INSERT INTO order_items
            (item_id, order_id, product_id, product_name, quantity, unit_price)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (item_id, order_id, item['product_id'],
              item['product_name'], item['quantity'], item['price']))

    conn.commit()
    conn.close()
    return get_order(order_id)

def get_order(order_id: str) -> dict:
    """Get order with all items"""
    conn = get_connection()
    order = conn.execute(
        "SELECT * FROM orders WHERE order_id = ?", (order_id,)
    ).fetchone()

    if not order:
        conn.close()
        return None

    items = conn.execute(
        "SELECT * FROM order_items WHERE order_id = ?", (order_id,)
    ).fetchall()

    conn.close()
    result = dict(order)
    result['items'] = [dict(i) for i in items]
    return result

def get_user_orders(user_id: str) -> list:
    """Get all orders for a user"""
    conn = get_connection()
    orders = conn.execute(
        "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC",
        (user_id,)
    ).fetchall()
    conn.close()
    return [dict(o) for o in orders]

def update_status(order_id: str, status: str):
    """Update order status"""
    conn = get_connection()
    conn.execute("""
        UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP
        WHERE order_id = ?
    """, (status, order_id))
    conn.commit()
    conn.close()

create_tables()
