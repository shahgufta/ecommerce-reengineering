# =============================================
# CART SERVICE — Modernized E-Commerce System
# SE-601 Software Re-Engineering
# Student: Shahgufta | KIU
# =============================================

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="Cart Service", version="1.0.0")

# In-memory cart storage
carts_db = {}

# ---- Models ----
class CartItem(BaseModel):
    product_id: str
    product_name: str
    price: float
    quantity: int

# ---- Routes ----

@app.get("/")
def home():
    return {"service": "Cart Service", "status": "running"}

@app.get("/cart/{user_id}")
def get_cart(user_id: str):
    """Get user's cart"""
    if user_id not in carts_db:
        return {"user_id": user_id, "items": [], "total": 0}
    
    items = carts_db[user_id]
    total = sum(item["price"] * item["quantity"] for item in items)
    return {"user_id": user_id, "items": items, "total": round(total, 2)}

@app.post("/cart/{user_id}/add")
def add_to_cart(user_id: str, item: CartItem):
    """Add item to cart"""
    if user_id not in carts_db:
        carts_db[user_id] = []
    
    # Check if product already in cart
    for existing in carts_db[user_id]:
        if existing["product_id"] == item.product_id:
            existing["quantity"] += item.quantity
            return {"message": "Cart updated", "cart": carts_db[user_id]}
    
    carts_db[user_id].append(item.dict())
    return {"message": "Item added to cart", "cart": carts_db[user_id]}

@app.delete("/cart/{user_id}/remove/{product_id}")
def remove_from_cart(user_id: str, product_id: str):
    """Remove item from cart"""
    if user_id not in carts_db:
        raise HTTPException(status_code=404, detail="Cart not found")
    
    carts_db[user_id] = [
        item for item in carts_db[user_id]
        if item["product_id"] != product_id
    ]
    return {"message": "Item removed", "cart": carts_db[user_id]}

@app.delete("/cart/{user_id}/clear")
def clear_cart(user_id: str):
    """Clear entire cart"""
    carts_db[user_id] = []
    return {"message": "Cart cleared successfully"}
