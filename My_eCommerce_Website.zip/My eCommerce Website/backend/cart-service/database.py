# ============================================================
# CART SERVICE — database.py
# Database models and operations for Cart Service
# SE-601 | Shahgufta | KIU
# ============================================================

import sqlite3
import uuid

DB_PATH = "cart.db"

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def create_tables():
    """Create cart table"""
    conn = get_connection()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cart (
            cart_id      TEXT PRIMARY KEY,
            user_id      TEXT NOT NULL,
            product_id   TEXT NOT NULL,
            product_name TEXT NOT NULL,
            price        REAL NOT NULL,
            quantity     INTEGER NOT NULL,
            added_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()
    print("Cart table ready!")

def get_cart(user_id: str) -> list:
    """Get all items in user's cart"""
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM cart WHERE user_id = ?", (user_id,)
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]

def add_item(user_id: str, product_id: str, product_name: str,
             price: float, quantity: int) -> dict:
    """Add item to cart (or update if already exists)"""
    conn = get_connection()

    # Check if product already in cart
    existing = conn.execute("""
        SELECT * FROM cart WHERE user_id = ? AND product_id = ?
    """, (user_id, product_id)).fetchone()

    if existing:
        # Update quantity
        conn.execute("""
            UPDATE cart SET quantity = quantity + ?
            WHERE user_id = ? AND product_id = ?
        """, (quantity, user_id, product_id))
    else:
        # Insert new item
        cart_id = str(uuid.uuid4())
        conn.execute("""
            INSERT INTO cart (cart_id, user_id, product_id, product_name, price, quantity)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (cart_id, user_id, product_id, product_name, price, quantity))

    conn.commit()
    conn.close()
    return get_cart(user_id)

def remove_item(user_id: str, product_id: str):
    """Remove item from cart"""
    conn = get_connection()
    conn.execute(
        "DELETE FROM cart WHERE user_id = ? AND product_id = ?",
        (user_id, product_id)
    )
    conn.commit()
    conn.close()

def clear_cart(user_id: str):
    """Clear entire cart for user"""
    conn = get_connection()
    conn.execute("DELETE FROM cart WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

def get_cart_total(user_id: str) -> float:
    """Calculate cart total"""
    conn = get_connection()
    result = conn.execute("""
        SELECT SUM(price * quantity) as total
        FROM cart WHERE user_id = ?
    """, (user_id,)).fetchone()
    conn.close()
    return round(result['total'] or 0, 2)

create_tables()
