-- ============================================================
-- LEGACY DATABASE SCHEMA
-- Problems annotated as comments
-- SE-601 | Shahgufta | KIU
-- ============================================================

CREATE DATABASE IF NOT EXISTS ecommerce_legacy;
USE ecommerce_legacy;

-- PROBLEM: Plaintext/MD5 passwords, no email_verified
CREATE TABLE users (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    email    VARCHAR(100),
    password VARCHAR(50),    -- PROBLEM: MD5 hash stored
    address  TEXT,           -- PROBLEM: Should be separate table
    is_admin INT DEFAULT 0   -- PROBLEM: Should be role/ENUM
);

-- PROBLEM: category stored as text (no foreign key)
CREATE TABLE products (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(200),
    description TEXT,
    price       DECIMAL(10,2),
    category    VARCHAR(100), -- PROBLEM: Should be FK to categories
    image       VARCHAR(255),
    stock       INT DEFAULT 0
);

-- PROBLEM: items stored as "1:2,3:1" string — 1NF VIOLATION!
CREATE TABLE orders (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT,           -- PROBLEM: No FK constraint
    items      TEXT,          -- PROBLEM: "product_id:qty,product_id:qty"
    total      DECIMAL(10,2),
    status     VARCHAR(20),   -- PROBLEM: No ENUM, any string accepted
    address    TEXT,          -- PROBLEM: Duplicated from users
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- PROBLEM: No FK constraints, orphaned records possible
CREATE TABLE cart (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT,           -- PROBLEM: No FK
    product_id INT,           -- PROBLEM: No FK
    quantity   INT
);

-- PROBLEM: No transaction_id, duplicate payments possible
CREATE TABLE payments (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,             -- PROBLEM: No FK
    amount   DECIMAL(10,2),
    method   VARCHAR(50),     -- PROBLEM: No ENUM
    status   VARCHAR(20)      -- PROBLEM: No ENUM
);
