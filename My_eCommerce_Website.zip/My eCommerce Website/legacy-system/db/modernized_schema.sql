-- ============================================================
-- MODERNIZED DATABASE SCHEMA (3NF Normalized)
-- SE-601 | Shahgufta | KIU
-- ============================================================

-- Proper categories table (was hardcoded text before)
CREATE TABLE categories (
    category_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name         VARCHAR(100) NOT NULL,
    description  TEXT,
    created_at   TIMESTAMP DEFAULT NOW()
);

-- Secure users table
CREATE TABLE users (
    user_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,  -- bcrypt hash
    role          VARCHAR(20) DEFAULT 'customer',
    is_active     BOOLEAN DEFAULT TRUE,
    created_at    TIMESTAMP DEFAULT NOW()
);

-- Proper products with FK to categories
CREATE TABLE products (
    product_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id UUID REFERENCES categories(category_id),
    name        VARCHAR(200) NOT NULL,
    description TEXT,
    price       DECIMAL(10,2) NOT NULL,
    stock       INTEGER DEFAULT 0,
    is_active   BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMP DEFAULT NOW()
);

-- Orders table (no more CSV items!)
CREATE TABLE orders (
    order_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID REFERENCES users(user_id),
    status     VARCHAR(20) DEFAULT 'pending',
    total      DECIMAL(10,2) NOT NULL,
    address    TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Separate order_items table (fixes 1NF violation)
CREATE TABLE order_items (
    item_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id   UUID REFERENCES orders(order_id),
    product_id UUID REFERENCES products(product_id),
    quantity   INTEGER NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL
);

-- Proper payments with transaction ID
CREATE TABLE payments (
    payment_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id       UUID REFERENCES orders(order_id),
    amount         DECIMAL(10,2) NOT NULL,
    method         VARCHAR(20) NOT NULL,
    status         VARCHAR(20) DEFAULT 'pending',
    transaction_id VARCHAR(100) UNIQUE,  -- No duplicates now!
    paid_at        TIMESTAMP
);

-- Cart table with proper FKs
CREATE TABLE cart (
    cart_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID REFERENCES users(user_id),
    product_id UUID REFERENCES products(product_id),
    quantity   INTEGER NOT NULL,
    added_at   TIMESTAMP DEFAULT NOW()
);
