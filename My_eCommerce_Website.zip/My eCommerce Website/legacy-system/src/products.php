<?php
// ============================================================
// LEGACY — products.php
// PROBLEM 1: SQL Injection vulnerability
// PROBLEM 2: HTML mixed with PHP and SQL
// PROBLEM 3: No pagination logic
// ============================================================
require('db_connect.php');

$search = isset($_GET['search']) ? $_GET['search'] : '';

// PROBLEM: SQL INJECTION! User input directly in query
$query = "SELECT * FROM products WHERE name LIKE '%" . $search . "%'";
$result = mysql_query($query);
?>
<html>
<body>
<h1>Products</h1>
<form method="GET">
    <input type="text" name="search" value="<?php echo $search; ?>">
    <button>Search</button>
</form>
<?php while($row = mysql_fetch_array($result)): ?>
    <div>
        <h3><?php echo $row['name']; ?></h3>  <!-- PROBLEM: No XSS protection -->
        <p>Price: <?php echo $row['price']; ?></p>
        <a href="?page=cart&add=<?php echo $row['id']; ?>">Add to Cart</a>
    </div>
<?php endwhile; ?>
</body>
</html>
