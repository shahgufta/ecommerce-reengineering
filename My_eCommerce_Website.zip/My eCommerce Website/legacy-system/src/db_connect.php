<?php
// ============================================================
// LEGACY — db_connect.php
// PROBLEM 1: Hardcoded credentials in source code
// PROBLEM 2: Using deprecated mysql_ functions
// PROBLEM 3: Global $conn variable used everywhere
// ============================================================
$conn = mysql_connect("localhost", "root", "admin123");  // HARDCODED PASSWORD!
mysql_select_db("ecommerce_legacy", $conn);

if (!$conn) {
    die("Connection failed");  // PROBLEM: Dies without logging
}
?>
