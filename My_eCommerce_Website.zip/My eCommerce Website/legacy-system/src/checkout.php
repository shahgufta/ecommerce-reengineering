<?php
// ============================================================
// LEGACY — checkout.php  (1200+ lines in real system!)
// PROBLEM 1: God File — everything in one place
// PROBLEM 2: No transaction management
// PROBLEM 3: SQL Injection in address field
// PROBLEM 4: No error handling — silent failures
// PROBLEM 5: 1NF violation — items stored as CSV string
// PROBLEM 6: No CSRF protection
// ============================================================
require('db_connect.php');
session_start();

$user_id = $_SESSION['user_id'];  // PROBLEM: No auth check

// PROBLEM: SQL Injection
$cart = mysql_query("SELECT * FROM cart WHERE user_id=" . $user_id);

$total = 0;
$items = array();

while($row = mysql_fetch_array($cart)) {
    // PROBLEM: N+1 query — SQL inside loop!
    $product = mysql_fetch_array(mysql_query(
        "SELECT * FROM products WHERE id=" . $row['product_id']
    ));
    $items[] = $row['product_id'] . ":" . $row['quantity'];
    $total += $product['price'] * $row['quantity'];
}

if(isset($_POST['place_order'])) {
    $items_str = implode(",", $items);    // PROBLEM: 1NF violation
    $address   = $_POST['address'];       // PROBLEM: No sanitization

    // PROBLEM: No transaction — if 2nd query fails, data is corrupted
    mysql_query("INSERT INTO orders (user_id,items,total,address,status)
                 VALUES ($user_id,'$items_str',$total,'$address','pending')");

    $order_id = mysql_insert_id();

    // PROBLEM: Payment always marked as paid — no actual verification!
    mysql_query("INSERT INTO payments (order_id,amount,method,status)
                 VALUES ($order_id,$total,'cod','paid')");

    // PROBLEM: No error check before clearing cart
    mysql_query("DELETE FROM cart WHERE user_id=" . $user_id);

    echo "<h2>Order Placed! Order ID: $order_id</h2>";
}
?>
<!-- PROBLEM: HTML mixed directly with PHP business logic -->
<html><body>
<h1>Checkout — Total: <?php echo $total; ?></h1>
<form method="POST">
    <!-- PROBLEM: No CSRF token -->
    <input type="text" name="address" placeholder="Your address">
    <button name="place_order">Place Order</button>
</form>
</body></html>
