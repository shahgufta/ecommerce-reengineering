<?php
// ============================================================
// LEGACY — user.php
// PROBLEM 1: MD5 password hashing (easily cracked)
// PROBLEM 2: SQL Injection in login
// PROBLEM 3: No session regeneration after login
// ============================================================
require('db_connect.php');
session_start();

if(isset($_POST['register'])) {
    $username = $_POST['username'];
    $email    = $_POST['email'];
    $password = md5($_POST['password']);  // PROBLEM: MD5 is NOT secure!

    // PROBLEM: SQL Injection
    mysql_query("INSERT INTO users (username,email,password)
                 VALUES ('$username','$email','$password')");
    echo "Registered!";
}

if(isset($_POST['login'])) {
    $email    = $_POST['email'];
    $password = md5($_POST['password']);

    // PROBLEM: SQL Injection via email field
    $result = mysql_query(
        "SELECT * FROM users WHERE email='$email' AND password='$password'"
    );
    if(mysql_num_rows($result) > 0) {
        $user = mysql_fetch_array($result);
        $_SESSION['user_id'] = $user['id'];  // PROBLEM: No session regeneration
        header("Location: index.php");
    } else {
        echo "Invalid credentials";
    }
}
?>
<html><body>
<form method="POST">
    <input type="email"    name="email"    placeholder="Email">
    <input type="password" name="password" placeholder="Password">
    <button name="login">Login</button>
    <button name="register">Register</button>
</form>
</body></html>
