<?php
// ============================================================
// LEGACY E-COMMERCE SYSTEM — index.php
// PROBLEM 1: No proper routing — uses GET params
// PROBLEM 2: Global DB connection via require
// PROBLEM 3: No input validation on $page
// ============================================================
session_start();
require('db_connect.php');

$page = isset($_GET['page']) ? $_GET['page'] : 'home';

if ($page == 'home')          include('products.php');
elseif ($page == 'cart')      include('cart.php');
elseif ($page == 'checkout')  include('checkout.php');
elseif ($page == 'login')     include('user.php');
elseif ($page == 'admin')     include('admin/index.php');
?>
